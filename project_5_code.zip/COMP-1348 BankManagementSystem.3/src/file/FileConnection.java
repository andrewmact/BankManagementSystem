package file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import bankException.InvalidAccountException;
import bankException.InvalidBankFileException;
import bankException.InvalidPasswordException;



public class FileConnection {
	///Users/main/Documents/COMP-1348 Submissions/Project folder
	private final static String STORAGE = "/Users/main/Documents/COMP-1348 Submissions/Project folder/BankAP.props";
	private final static String STORE_EMAIL = "/Users/main/Documents/COMP-1348 Submissions/Project folder/BankAE.props";

/**
 * Static initializer is to make sure the files are created 
 * before they are attempted to be accessed
 * 
 * if they do not exist create a new file
 */
 static	{
		File f1 = new File(STORAGE);
		File f2 = new File(STORE_EMAIL);
		if(!(f1.exists())){
			try {
				f1.createNewFile();
			} catch (IOException e) { e.printStackTrace();}
		}
		if(!(f2.exists())){
			try {
				f2.createNewFile();
			} catch (IOException e) { e.printStackTrace();}
		}
	}
	/**
	 * @param accountNo: users account number
	 * @param password: users account password
	 * @return: returns true if the file is stored
	 * 			returns false if an exception is thrown during the process
	 * 
	 * Method is used to write into the Bank Account Password file.
	 * This file creates a relationship between a account number and password
	 */
	public static boolean writeInPasswordFile(int accountNo, String password) {
			String accountNumber = Integer.toString(accountNo);
			
			Lock passwordFile = new ReentrantLock();
			passwordFile.lock();
		try(FileOutputStream file = new FileOutputStream(STORAGE)) {
			Properties prop = new Properties();
			
			prop.setProperty(accountNumber, password);
			prop.store(file, null);
			file.flush();
			return true;
		}
		catch(IOException e) {
			e.printStackTrace();
			return false;
		} 
		finally {
			passwordFile.unlock();
		}
	}
	/**
	 * @param accountNo: users account number
	 * @param email: users account email
	 * @return returns true if the file is stored
	 * 			returns false if an exception is thrown during the process
	 * 
	 * Method is used to write into the Bank Account Email file.
	 * This file creates a relationship between a account number and email
	 */
	public static boolean writeInEmailFile(int accountNo, String email) {
			String accountNumber = Integer.toString(accountNo);
			
			Lock emailFile = new ReentrantLock();
			emailFile.lock();
		try(FileOutputStream file = new FileOutputStream(STORE_EMAIL)) {
			Properties prop = new Properties();
		
			prop.setProperty(accountNumber, email);
			prop.store(file, null);
			file.flush();
			return true;
		} 
		catch(IOException e) { 
			e.printStackTrace(); return false;
		} 
		finally {
			emailFile.unlock();
		}
	}
	//READ
	/**
	 * @param accountNo: users account number
	 * @param password: users account password
	 * @return:returns true if the users account number and password matches 
	 * an instance in the bank account number password file
	 * 
	 * @throws InvalidAccountException: exception is thrown if the account number does not match a key in the file
	 * @throws InvalidPasswordException: exception is thrown if the key's value does not match the users entered password
	 * @throws InvalidBankFileException: exception is thrown if a IOException occurs. To share which method caused a file error
	 * 
	 * Method is used to read the account number password file to see if the users entered account number and password matchs the filed account information
	 */
	public static boolean readFromPasswordFile(int accountNo, String password) throws InvalidAccountException, InvalidPasswordException, InvalidBankFileException {
			String accountNumber = Integer.toString(accountNo);
		try(FileInputStream in = new FileInputStream(STORAGE)) {
			Properties prop = new Properties();
			prop.load(in);
			
			if(prop.containsKey((Object)accountNumber)) {
				String value = prop.getProperty(accountNumber);
				if(value.equals(password)) {	
					return true;
				} else {
					throw new InvalidPasswordException("Password does not match");
				}
			} else {
				throw new InvalidAccountException("Account not found");
			}
		} catch (IOException e) {
			throw new InvalidBankFileException("Read PasswordFile error", e.getCause());
		} 
	}
	/**
	 * @param accountNo: users account number
	 * @param email: users account email
	 * @return:returns true if the users account number and email matches 
	 * an instance in the bank account number password file
	 * 
	 * @throws InvalidAccountException: exception is thrown if the account number does not match a key in the file
	 * @throws InvalidBankFileException: exception is thrown if a IOException occurs. To share which method caused a file error
	 * 
	 * Method is used to read the account number email file to see if the users entered account number and email matchs the filed account information
	 */
	public static boolean readFromEmailFile(int accountNo, String email) throws InvalidAccountException, InvalidBankFileException {
		String accountNumber = Integer.toString(accountNo);
		try(FileInputStream in = new FileInputStream(STORE_EMAIL)) {
			Properties prop = new Properties();
			prop.load(in);
		
			if(prop.containsKey((Object)accountNumber)) {
				String value = prop.getProperty(accountNumber);
				if(value.equals(email)) {	
					return true;
				} else {
					return false;
				}
			} 
			throw new InvalidAccountException("Account not found");
		}
		catch (IOException e) {
			throw new InvalidBankFileException("Read EmailFile error", e.getCause());
		}
	}
	
	//MODIFY
	/**
	 * @param accountNo: users account number
	 * @param newPassword: users new password
	 * @throws InvalidBankFileException: exception is thrown if a IOException occurs. To share which method caused a file error
	 * 
	 * Method updates a users password to their new requested password in the account number password file
	 */
	public static void modifyPasswordFile(int accountNo, String newPassword) throws InvalidBankFileException{
		String num = Integer.toString(accountNo);
		FileOutputStream file = null;
		
		try(FileInputStream in = new FileInputStream(STORAGE)){
			Properties prop = new Properties();
			prop.load(in);
			
			prop.replace(num, newPassword);
		
		    file = new FileOutputStream(STORAGE);
			prop.store(file, null);
			file.flush();
			file.close();
		}
		catch(IOException e) {
			throw new InvalidBankFileException("Modify PasswordFile error", e.getCause());
		}
	}
	/**
	 * @param accountNo: users account number
	 * @param email: users new email
	 * @throws InvalidBankFileException: exception is thrown if a IOException occurs. To share which method caused a file error
	 * 
	 * Method updates a users email to their new requested email in the account number password file
	 */
	public static void modifyEmailFile(int accountNo, String newEmail) throws InvalidBankFileException {
		String accountNumber = Integer.toString(accountNo);
		FileOutputStream file = null;
		
		try(FileInputStream in = new FileInputStream(STORE_EMAIL)){
			Properties prop = new Properties();
				prop.load(in);
				prop.replace(accountNumber, newEmail);
				
				file = new FileOutputStream(STORE_EMAIL);
				prop.store(file, null);
				file.flush();
				file.close();
		}
		catch(IOException e) {
			throw new InvalidBankFileException("Modify EmailFile error", e.getCause());
		}
	}
	
	//RECOVER
	/**
	 * @param accountNo: users account number
	 * @return: returns the accounts password if the account number macths a key in the account number password file
	 * 
	 * @throws InvalidBankFileException: exception is thrown if a IOException occurs. To share which method caused a file error
	 * @throws InvalidAccountException: exception is thrown if the file does not contain the users entered account number
	 * 
	 * Method recovers a users account password by passing the users account number into the account number password file
	 */
	public static String recoverPassword(String accountNo) throws InvalidBankFileException, InvalidAccountException {
		try (FileInputStream in = new FileInputStream(STORAGE)) {
			Properties prop = new Properties();
			 prop.load(in);
			 
			 if(prop.containsKey(accountNo)) {
					String value = prop.getProperty(accountNo);
					return value;
			 }
			 throw new InvalidAccountException("No account found in File");
		} catch (IOException e) {
			throw new InvalidBankFileException("Recover PasswordFile error", e.getCause());
		}
	}
	/**
	 * @param email: users account email
	 * @return: returns a users account number by matching the users account email in the account number email file
	 * 
	 * @throws InvalidAccountException: exception is thrown if a account number is not found
	 * @throws InvalidBankFileException: exception is thrown if a IOException occurs. To share which method caused a file error
	 * 
	 * Method recovers a users account email by streaming through the account number email file
	 */
	public static String recoverAccount(String email) throws InvalidAccountException, InvalidBankFileException {
		try (FileInputStream in = new FileInputStream(STORE_EMAIL)) {
			 Properties prop = new Properties();
				prop.load(in);
				
				Set<String> keys = prop.stringPropertyNames();
				
			    Optional<String> key =  keys.stream()
			    							 .parallel()
						 					 .filter((k)->{String e = prop.getProperty(k); return e.equals(email);})
						 					 .findAny();
					 
				  if(key.isPresent()) {
					  String compare = prop.getProperty(key.get());
					  if(email.equals(compare)) {
						  return key.get();
					  }
					  throw new InvalidAccountException("Account Email Error");
				  }
				  throw new InvalidAccountException("No account found");
		} catch (IOException e) {
			throw new InvalidBankFileException("Recover EmailFile error", e.getCause());
		}
	}

	//REMOVE
	/**
	 * @param accountNo: users account number
	 * @param password: users account password
	 * @throws InvalidBankFileException: exception is thrown if a IOException occurs. To share which method caused a file error
	 * 
	 * Method is used to remove a key value pair from the account number password file
	 */
	public static void removeAccountPassword(int accountNo, String password) throws InvalidBankFileException {	
		String num = Integer.toString(accountNo);
		try (FileInputStream in = new FileInputStream(STORAGE)) {
			Properties prop = new Properties();
			prop.load(in);
			prop.remove(num, password);
		} catch(IOException e) {
			throw new InvalidBankFileException("Account Password not removed from file");
		}
	}
	/**
	 * @param accountNo: users account number
	 * @param email: users account wmail
	 * @throws InvalidBankFileException: exception is thrown if a IOException occurs. To share which method caused a file error
	 * 
	 * Method is used to remove a key value pair from the account number email file
	 */
	public static void removeAccountEmail(int accountNo, String email) throws InvalidBankFileException {	
		String num = Integer.toString(accountNo);
		try (FileInputStream in = new FileInputStream(STORE_EMAIL)) {
			Properties prop = new Properties();
			prop.load(in);
			prop.remove(num, email);
		} catch(IOException e) {
			throw new InvalidBankFileException("Account Email not removed from file");
		}
	}
	
}
