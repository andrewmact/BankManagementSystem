package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

public class TransactionTable extends DatabaseConnection {
	/**	
	 * Transaction Table
	 * 
	 * idTransaction: PK, NN, AI
	 * AccountNo (int): NN
	 * ActionType(int): NN
	 * Amount (int): NN
	 * Date (DateTime): NN
	 */
	public static void insert(int accountNo, String account, int action, int amount) {
		try(Connection con = connectDB();){
			
			String query = "SELECT* FROM Transaction";
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			ResultSet rs = stmt.executeQuery(query);
			rs.next();
			rs.moveToInsertRow();
			
			rs.updateInt("AccountNo", accountNo);
			rs.updateInt("ActionType", action);
			rs.updateInt("Amount", amount);

			Date day = Date.valueOf(LocalDate.now());
			rs.updateDate("Date", day);
			
			rs.insertRow();
			rs.moveToCurrentRow();

			rs.close();
			stmt.close();			
		}
		catch(SQLException sql) {
			
		}
	}
	
	public static void delete(int transactionID) {
		
		try(Connection con = connectDB();){
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			String query = "SELECT* FROM Transaction WHERE idTransaction = "+transactionID;
			
			ResultSet rs = stmt.executeQuery(query);
			rs.deleteRow();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
