package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import accounts.ChequingAccount;
import accounts.CustomerAccount;
import accounts.CustomerAccount.CreditCard;
import accounts.SavingsAccount;

public class AccountTable extends DatabaseConnection{
	/**		
	 * Account Table
	 * 
	 * Entry: PK, NN, AI
	 * AccountID (int): NN
	 * Balance (int): NN
	 * AccountTypeID (int 1-3): NN
	 * AccountLimit (int): NN
	 * LastLoggedIn (date): NN
	 */
	public static void insert(int accountNo, int accountType, int limit) {
		try(Connection con = connectDB();){
			String query = "SELECT* FROM Account";
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			ResultSet rs = stmt.executeQuery(query);
			rs.next();
			rs.moveToInsertRow();
			
			rs.updateInt("AccountID", accountNo);
			rs.updateInt("Balance", 0);
			rs.updateInt("AccountTypeID", accountType);
			rs.updateInt("AccountLimit", limit);
			Date date = Date.valueOf(LocalDate.now());
			rs.updateDate("LastLoggedIn", date);
			
			rs.insertRow();
			rs.moveToCurrentRow();
			
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * @param account: the customers account object
	 * @param accountNo: the customers bank account number used to locate accounts
	 * @return: An instance representing the users bank account
	 * 
	 * This method copies each instance of a users bank account into their main account called account
	 * This is done by querying the bank database
	 * The method traverses the bank database gathering all information about a type of bank account
	 * The method then uploads this information into the instance of the users main account via setAccount
	 */
	public static CustomerAccount getAccount(CustomerAccount account, int accountNo) {
		try(Connection con = connectDB();){
			String query = "SELECT* FROM Account WHERE AccountID = "+accountNo;
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			while(rs.next()) {
			int accountType = rs.getInt("AccountTypeID");
			int limit =	rs.getInt("AccountLimit");
			int balance = rs.getInt("Balance");
			
			setAccount(accountType, account, limit, balance);
			}
		} catch (SQLException sql) {
			System.out.println(sql.getMessage());
		}
		return account;
	}
	
	public static void updateBalance(int accountNo, int accountType, int amount) {
		try(Connection con = connectDB();){
			String query = "UPDATE Account SET Balance ="+amount+" WHERE AccountID = "+accountNo+" AND AccountTypeID = "+accountType+" AND EntryNo <> 0;";
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			int rs = stmt.executeUpdate(query);
			
			if(rs < 0 || rs > 1) {
				stmt.cancel();
				throw new SQLException(rs+" rows updated");
			}
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void updateLoggedIn(int accountNo, int accountType) {
		try(Connection con = connectDB();){
			String query = "SELECT* FROM Account WHERE AccountID = "+accountNo+" AND AccountTypeID = "+accountType+" AND EntryNo <> 0;";
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = stmt.executeQuery(query);
			
			rs.next();
			Date date = Date.valueOf(LocalDate.now());
			rs.updateDate("LastLoggedIn", date);
			rs.updateRow();
			
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static boolean deleteAccount (int accountNo, int accountType) {
		boolean isDeleted = false;
		try(Connection con = connectDB();){
			String query = "SELECT* FROM Account WHERE AccountID = "+accountNo+" AND AccountTypeID = "+accountType;
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			ResultSet rs = stmt.executeQuery(query);
			rs.next();
			rs.deleteRow();
			rs.close();
			stmt.close();
			isDeleted = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isDeleted;
	}
	/**
	 * @param type: type of bank account ie Chequing Account, Saving Account, Credit Card
	 * @param account: the instance of the users main account
	 * @param limit: the bank accounts limit for expendatures
	 * @param balance: the bank accounts listed balance
	 * 
	 * This method receives information from the bank database 
	 * and relies it into a bank account of the users main account
	 * It chooses the bank account based off the typeID which is pre-determined
	 */
	static void setAccount(int type, CustomerAccount account, int limit, int balance) {
		switch(type) {
		case 1: account.setChequing();
				ChequingAccount c = account.getChequing();
								c.setOverDraft(limit);
								c.setBalance(balance);
			break;
		case 2: account.setSavings();
				SavingsAccount s = account.getSavings();
							   s.setMinBalance(limit);
							   s.setBalance(balance);
			break;
		case 3: account.setCreditCard();
				CreditCard cc = account.getCreditCard();
						   cc.setLimit(limit);
						   cc.setBalance(balance);
			break;
		}
	}
	
	
}