package database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import accounts.CustomerAccount;

public class CustomerTable extends DatabaseConnection{
	/**	
	 * Customer Table
	 * 
	 * CustomerID: PK, NN, AI
	 * Name (varchar 30): NN
	 * Password (varchar 30): NN
	 * Email (varchar 45): NN
	 * 
	 */
	int customerID;
	public static void insert(int accountNo, String name, String password, String email) {
		try(Connection con = connectDB();){
			String query = "SELECT* FROM Customer";
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			ResultSet rs = stmt.executeQuery(query);
			rs.next();
			rs.moveToInsertRow();
			
			rs.updateInt("idCustomer", accountNo);
			rs.updateString("Name", name);
			rs.updateString("Password", password);
			rs.updateString("Email", email);
			rs.insertRow();
			rs.moveToCurrentRow();	
			
			rs.close();
			stmt.close();
		}
		catch(SQLException sql){
			sql.printStackTrace();
		}
	}
	
	public static CustomerAccount getCustomerInfo(CustomerAccount account, int accountNo) {
		try(Connection con = connectDB();){
			String query = "SELECT* FROM Customer WHERE idCustomer = "+accountNo;
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			while(rs.next()) {
			String name = rs.getString("Name");
			String email =	rs.getString("Email");
				account.setName(name);
				account.setEmail(email);
			}
		} catch (SQLException sql) {
			System.out.println(sql.getMessage());
		}
		return account;
	}
	
	public static void updatePassword(int accountNo, String password) {
		try(Connection con = connectDB();){
			String query = "UPDATE Customer SET Password = '"+password+"' WHERE idCustomer = "+accountNo;
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			int rs = stmt.executeUpdate(query);
			
			if(rs < 0 || rs > 1) {
				stmt.cancel();
				throw new SQLException(rs+" rows updated");
			}
			stmt.close();
		}
		catch(SQLException sql) {
			sql.printStackTrace();
		}
	}
	
	public static void updateEmail(int accountNo, String email) {
		try(Connection con = connectDB();){
			String query = "UPDATE Customer SET Email = '"+email+"' WHERE idCustomer = "+accountNo;
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			int rs = stmt.executeUpdate(query);
			
			if(rs < 0 || rs > 1) {
				stmt.cancel();
				throw new SQLException(rs+" rows updated");
			}
			stmt.close();
		}
		catch(SQLException sql) {
			sql.printStackTrace();
		}
	}
	
	public static void deleteAccount(int accountNo) {
		try(Connection con = connectDB();){
			String query = "DELETE FROM Customer WHERE idCustomer = "+accountNo;
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			int rs = stmt.executeUpdate(query);
			
			if(rs < 0 || rs > 1) {
				stmt.cancel();
				throw new SQLException(rs+" rows deleted");
			}
			stmt.close();
		}
		catch(SQLException sql) {
			sql.printStackTrace();
		}
	}
}
