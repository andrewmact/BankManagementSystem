package accounts;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import accounts.CustomerAccount.CreditCard;
import bankException.InvalidAccountException;

class TestCredit extends TestBankAccount{
	  CreditCard test;
//getCard()	
//getCardWith(int amount)
//getCardLimitWith(int limit, int amount)	  

	@Test
	void inheritanceTest() {						
		test = getCard();
			assertNotNull(test);
	}

	@Test
	void getBalanceTest() {
		 test = getCardLimitWith(500, 100);
		 	assertNotNull(test);
		 	assertNotEquals(0, test.getBalance());
		 	assertEquals(100, test.getBalance());
	}
//getCardLimitWithSavingsAndChequing
//(CreditCard limit (500), CreditCard balance (250), Minimum savings limit (0), 
// chequing OverDraft limit (1000), savings balance (100), chequing balance (500)) 
	@Test
	void withDrawalTest() {
		 try {									
			test = getCardLimitWithSavingsAndChequing(500, 250, 0, 1000, 100, 500);
		} catch (InvalidAccountException e) {
			// From creating the account
			e.printStackTrace();
		}
		 	assertEquals(true, test.payBalance(0, "c"));
		 	assertEquals(true, test.payBalance(125, "c"));
		 	assertEquals(125, test.getBalance());
		 	
			assertEquals(true, test.payBalance(0, "s"));
		 	assertEquals(false, test.payBalance(125, "s"));
		 	assertEquals(125, test.getBalance());
		 	
		 	assertEquals(true, test.payBalance(100, "s"));
		 	assertEquals(25, test.getBalance()); 		
	}

	@Test
	void depositeTest() {
		 test = getCardLimit(100);
		 	assertEquals(true, test.credit(0));
		 	assertEquals(true, test.credit(50));
		 	assertEquals(50, test.getBalance());
		 
		 	assertEquals(false, test.credit(50));
		 	assertEquals(50, test.getBalance());
		 	
		 	assertEquals(true, test.credit(49));
		 	assertEquals(99, test.getBalance());
	}

	@Test
	void validateTransactionTest() {
		 test = getCard();
		 	assertEquals(false, test.validateTransaction(1));
		 
		 test = getCardLimit(250);
		 	assertEquals(true, test.validateTransaction(0));
		 	assertEquals(true, test.validateTransaction(249));
		 	assertEquals(false, test.validateTransaction(250));
	}
	
	@Test
	void testValidAmount() {
		 test = getCard();
			assertEquals(0, test.validate(0));
			assertEquals(1, test.validate(1));
			
			boolean isIncorrect = false;
			try{
			test.validate(-1);
			} catch(IllegalArgumentException ex) {
				isIncorrect = true;
			}
			assertEquals(true, isIncorrect);
	}

}
