package accounts;

import database.AccountTable;

public class SavingsAccount extends BankAccount {
	private int accountNo;
	private int minBalance = 0;
	private int balance;
	
	SavingsAccount(int accountNo){
		this.accountNo = accountNo;
	}
	
	Transactionable log = (a, m)->{
		Transactionable.logTransfer(accountNo, "Savings" , a, m);
	};
	
	public void setMinBalance(int amount) {
		try {
			validate(amount);
		} catch(IllegalArgumentException ex) {
	 		amount *= -1;
	 	}
		minBalance = amount;
	}

	public int getMinBalance() {
		return minBalance;
	}
	@Override
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public int getBalance() {
		return balance;
	}
	@Override
	public boolean withDrawal(int amount) {
		try {
			validate(amount);
		} catch(IllegalArgumentException ex) {
	 		amount *= -1;
	 	}
		
		if(validateTransaction(amount)) {
		balance -= amount;
		log.getTransfer("Withdraw", amount);
		return true;
		}
		return false;
	}

	@Override
	public boolean deposite(int amount) {
		try {
			validate(amount);
		} catch(IllegalArgumentException ex) {
	 		amount *= -1;
	 	}
		
		balance += amount;
		log.getTransfer("Deposit", amount);	
		return true;
	}
	
	@Override
	boolean validateTransaction(int amount) {
		assert(amount >= 0);
			
		if(balance < amount) return false;
				
			int	difference = balance - amount;
			if((difference >= minBalance)) {
				return true;
				} else {
				return false;
			}			
	}
	
	int validate(int amount) {
			if(amount >= 0) {
				return amount;
			} 
		throw new IllegalArgumentException();
			
	}	
	public void exitAccount() {
		 AccountTable.updateBalance(accountNo, 2, balance);
	}
}
