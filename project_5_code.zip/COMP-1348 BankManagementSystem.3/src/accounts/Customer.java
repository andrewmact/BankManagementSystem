package accounts;

import bankException.InvalidBankFileException;
import bankException.InvalidPasswordException;
import database.CustomerTable;
import file.FileConnection;

public class Customer {
	
	private	int accountNumber;
	private	String name;
	private	String password;
	private String email;
	FileConnection file = new FileConnection();


	Customer(){}
	Customer(int accountNumber, String password) throws InvalidPasswordException{
		this.accountNumber = accountNumber;
		try {
			setPassword(password);
		} catch(InvalidPasswordException e) {
			throw new InvalidPasswordException("Password is invalid", e);
		}
	}
	/**
	 * 
	 * @param accountNumber: Bank account number
	 * @param name: Customers name
	 * @param password: Customers created password
	 * 
	 * @throws InvalidPasswordException: thrown if the customers created password does not meet the minimum requirements
	 * 
	 * setPassword(password): is a setter method for the password variable
	 * 						  This method helps verify if the password created is a valid password for the customer to have	
	 */
	Customer(int accountNumber, String name, String password, String email) throws InvalidPasswordException {
		this.accountNumber = accountNumber;
		this.name = name;
		this.email = email;
		
		try {
			setPassword(password);
		} catch(InvalidPasswordException e) {
			throw new InvalidPasswordException("Password is invalid", e);
		}
	}
	
	
//----------setters----------\\ 
	protected void setAccountNo(int accountNumber) {
		assert(accountNumber > 999999 || accountNumber < 10000000);
		this.accountNumber = accountNumber;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @param password: users password
	 * @throws InvalidPasswordException: thrown is the password is considered invalid from validatePassword(password)
	 * 
	 * If the password is considered valid, set the password, else throw the exception
	 */
	protected void setPassword(String password) throws InvalidPasswordException {
			if(validatePassword(password)) {
			this.password = password;
			} else {
				throw new InvalidPasswordException("Password does not exceed the minimum length of 8");
		    }
	}
//----------getters----------\\
	public int getAccountNo() {
		return accountNumber;
	}
	public String getName() {
		return name;
	}
	public String getPassword() {
		return password;
	}
	public String getEmail() {
		return email;
	}
//----------Valid Password----------\\
	/**
	 * 
	 * @param password: users password
	 * @return: true if the password is longer than 7 character
	 * 			false if the password is shorter or equal to 7 characters
	 * 
	 *  A password must be at least 8 characters to be considered valid
	 */
	public boolean validatePassword(String password) {
		return password.length() > 7;	 
	}
	/**
	 * @param currentPassword: users entered current password
	 * @param newPassword: the new password the user would like to set
	 * 
	 * @throws InvalidPasswordException: throws if the password the user entered does not match the account password
	 * 									 throws if an exception occurs while trying to set the new password adding an additional message that the new password is invalid
	 */
	public void changePassword(String currentPassword, String newPassword) throws InvalidPasswordException {
		
			if(getPassword().equals(currentPassword)) {
				file = new FileConnection();
				try {
					setPassword(newPassword);
					FileConnection.modifyPasswordFile(getAccountNo(), newPassword);
					CustomerTable.updatePassword(getAccountNo(), newPassword);
					return;
				} 
				catch(InvalidPasswordException e) {
					throw new InvalidPasswordException("new password is invalid", e);
				} catch (InvalidBankFileException e) {
						 e.printStackTrace();
				}
			} 
			else {
			throw new InvalidPasswordException("Passwords do not match");
			}
		} 
	
	public void changeEmail(String currentEmail, String newEmail) {
		try {
			if(currentEmail.equals(email)) {
				setEmail(newEmail);
				FileConnection.modifyEmailFile(getAccountNo(), newEmail);
				CustomerTable.updateEmail(getAccountNo(), newEmail);
			} 
		} 
		catch(InvalidBankFileException e) {
			  e.printStackTrace();
		}
	}
	
}
