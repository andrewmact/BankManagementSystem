package accounts;

public abstract class BankAccount 
{	
	abstract int getBalance();
	abstract void setBalance(int balance);
	abstract boolean withDrawal(int amount);
	abstract boolean deposite(int amount);
	abstract boolean validateTransaction(int amount);
}
