package accounts;

import database.TransactionTable;

@FunctionalInterface
public interface Transactionable {
	 
	
	//Functional method\\
	/**
	 * @param action: this refers to the type of transaction ie withdrawal, deposit, etc
	 * @param amount: the amount of money being transacted
	 * 
	 * This functional method will be used inside the different banking features 
	 * to gather information on the transaction that is being performed
	 * the functional method will get/consume this information and invoke
	 * the log transfer method
	 */
	abstract void getTransfer(String action, int amount);
	
	// Database caller \\
	/**
	 * @param accountNo: customers account number
	 * @param account: the type of bank account; chequing, savings, credit card
	 * @param action: the transaction type; withdrawal, deposit
	 * @param amount: the amount of money being transacted
	 * 
	 * type = checkTransaction(action): gets the transaction type identification number 
	 * 									this is used to help identify transaction in the database
	 * TransactionTable.intsert(...): Is a method that connects to the Transaction table in the Bank Management System Database
	 * 								  This method helps insert the required information to submit a query into the Transaction table
	 */
	static void logTransfer(int accountNo, String account, String action, int amount) {
		int type = checkTransaction(action);
		TransactionTable.insert(accountNo, account, type, amount);
	}	
	/**
	 * @param action: tyoe if transaction
	 * @return: identification number ie TransactionType table primary key.
	 * 
	 * This method takes the action string and converts it to its identification number
	 */
	static int checkTransaction(String action) {
		switch(action) {
		case"Withdraw": return 1;
		case"Deposit": return 2;
		case"Credit": return 3;
		case"PayCredit": return 4;
		}
		return -1;
	}
	
}//END INTERFACE
