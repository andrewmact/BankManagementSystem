package accounts;

import bankException.InvalidAccountException;
import bankException.InvalidPasswordException;
import database.AccountTable;

public class CustomerAccount extends Customer{
	
	public CustomerAccount(){};
	public CustomerAccount(int accountNo, String password) throws InvalidPasswordException{
		super(accountNo, password);
	};
	/**
	 * Creating Customer Account object
	 * @param accountNo: The bank account number
	 * @param name: The users name
	 * @param password: The users password
	 * 
	 * @throws InvalidPasswordException: thrown if the password the user created does not meet the password requirerments
	 * 
	 * createChequingAccount(500): is used to set up a default bank account for the new customer
	 */
	public CustomerAccount(int accountNo, String name, String password, String email) throws InvalidPasswordException {
		super(accountNo, name, password, email);
		createChequingAccount(500);
	}
		
	private SavingsAccount savingsAccount;
	private ChequingAccount chequingAccount;
	private CreditCard creditCard;
	/**
	 * @param account: the bank account being checked to see if it has been initialized
	 * @return: true if account has been initialized
	 * 			false if the account is currently null
	 */
	static boolean accountExists(Object account){
		return account != null;
	}
	//SET ACCOUNTS
//	public void test() {
//		Account<SavingsAccount> test = new Account<SavingsAccount>();
//		
//	}
	public void setSavings() {
		   savingsAccount = new SavingsAccount(getAccountNo());			
	}
	public void setChequing() {
		   chequingAccount = new ChequingAccount(getAccountNo());
	}
	public void setCreditCard() {
		   creditCard = new CreditCard(getAccountNo());
	}
	
	//GET ACCOUNTS
	public SavingsAccount getSavings() throws NullPointerException {
			if(accountExists(savingsAccount)) { 
				AccountTable.updateLoggedIn(getAccountNo(), 2);
				return savingsAccount;
			}
				throw new NullPointerException("Savings account does not exist");	
	}
	public ChequingAccount getChequing() throws NullPointerException {
			if(accountExists(chequingAccount)) {
				AccountTable.updateLoggedIn(getAccountNo(), 1);
				return chequingAccount;
			}
				throw new NullPointerException("Chequing account does not exist");
	}
	public CreditCard getCreditCard() throws NullPointerException {
		if(accountExists(creditCard)) { 
			AccountTable.updateLoggedIn(getAccountNo(), 3);
			return creditCard;
		}
			throw new NullPointerException("Credit Card account does not exist");
	}
	//CREATE ACCOUNTS
	/**
	 * @param: takes a int value that represents their account limit
	 * @return: true, if the account was able to be created
	 * 			false if the account already exists
	 * 
	 * !(accountExists(account):checks to see if the account exists, if it does not exists, I want to proceed
	 * 		if the account does not exist: I initialize the account by creating a new account and passing in the account number associated.
	 * 									   I initialize the accounts limit variable to the requested amount
	 * 									   I insert the account into the AccountTable in the Banks Database
	 * 
	 */
	public boolean createSavingsAccount(int minBalance) {
		if(!(accountExists(savingsAccount))) {
			savingsAccount = new SavingsAccount(getAccountNo());
			savingsAccount.setMinBalance(minBalance);
			AccountTable.insert(getAccountNo(), 2, minBalance);
			return true;
		}
			return false;
	}
	public boolean createChequingAccount(int overDraft) {
		if(!(accountExists(savingsAccount))) {
			chequingAccount = new ChequingAccount(getAccountNo());
			chequingAccount.setOverDraft(overDraft);
			AccountTable.insert(getAccountNo(), 1, overDraft);
			return true;
		}
			return false;
	}
	public boolean createCreditCard(int limit) {
		if(!(accountExists(savingsAccount))) {
			creditCard = new CreditCard(getAccountNo());
			creditCard.setLimit(limit);
			AccountTable.insert(getAccountNo(), 3, limit);
			return true;
		}
			return false;
	}
	//REMOVE ACCOUNTS
	public void removeSavingsAccount(SavingsAccount account) throws InvalidAccountException {
			if(account.getBalance() == 0) {
				savingsAccount = null;
				AccountTable.deleteAccount(getAccountNo(), 2);
				return;
			}
				throw new InvalidAccountException("Savings Account holds balance");
	}
	public void removeChequingAccount(ChequingAccount account) throws InvalidAccountException {	
			if(account.getBalance() == 0) {
				chequingAccount = null;
				AccountTable.deleteAccount(getAccountNo(), 1);
				return;
			}
				throw new InvalidAccountException("Savings Account holds balance");
	}
	public void removeCreditCard(CreditCard card) throws InvalidAccountException {
			if(card.getBalance() == 0) {
				creditCard = null;
				AccountTable.deleteAccount(getAccountNo(), 3);
				return;
			}
				throw new InvalidAccountException("Credit Card holds balance");
	}
	
//----------Credit card class----------\\
public class CreditCard {
	private int accountNo;
	private int limit;
	private int balance;
/**
 * @param accountNo: customer account number
 *
 * The constructor takes the customers account number to identify the account that performed the transaction
 */
	CreditCard(int accountNo){
		this.accountNo = accountNo;
	}
	
	Transactionable log = (a, m)->{
		Transactionable.logTransfer(accountNo, "Credit Card", a, m);
	};
	
	
	public void setLimit(int amount) {
		try {
			validate(amount);
		} catch(IllegalArgumentException ex) {
	 		amount *= -1;
	 	}
		limit = amount;
	}
	
	public int getLimit() {
		return limit;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public int getBalance() {
		return balance;
	}

	public boolean credit(int amount) {
		try {
			validate(amount);
		} catch(IllegalArgumentException ex) {
	 		amount *= -1;
	 	}
		
		if(validateTransaction(amount)) {
			balance += amount;
			log.getTransfer("Credit", amount);
			return true;
		}
		return false;
	}

	public boolean payBalance(int amount, String account) {
		BankAccount useAccount = null;
		try {
			validate(amount);
		} catch(IllegalArgumentException ex) {
			amount *= -1;
		}
		
		try	{
			if(account.equals("c")) {
				useAccount = getChequing();
			} else if(account.equals("s")) {
				useAccount = getSavings();
			}
		} catch(NullPointerException ex) {
			ex.printStackTrace();
		}
			if(useAccount.withDrawal(amount)) {
				balance -= amount;
				log.getTransfer("PayCredit", amount);
				return true;
			} else {
				return false;
			}
		}

	
	protected boolean validateTransaction(int amount) {
		assert(amount >= 0);
		
		if((balance + amount) < limit){
			return true;
		} else {
			System.out.println("Credit Card declined: Over limit");
				return false;
		}
	}
	
	int validate(int amount) {
			if(amount >= 0) {
				return amount;
			} else {
		throw new IllegalArgumentException();
			}
	}
	public void exitAccount() {
		 AccountTable.updateBalance(accountNo, 3, balance);
	}
	
}

	/**
	 * hashCode: represents my customeraccounts value 
	 */
	public int hashCode() {
		return getAccountNo();
	}
	/**
	 * equals: determines my customeraccount value when compared
	 */
	public boolean equals(Object o) {
		if((o instanceof Customer) && ((CustomerAccount) o).getAccountNo() == this.getAccountNo()) {
			return true;
		}
			return false;
	}
	
}
