package accounts;

import database.AccountTable;

public class ChequingAccount extends BankAccount {
	private int accountNo;
	private int overDraft = 0;
	private int balance;
	
	Transactionable log = (a, m)->{
		Transactionable.logTransfer(accountNo, "Chequing", a, m);
	};

	ChequingAccount(int accountNo){
		this.accountNo = accountNo;
	}
	
	public void setOverDraft(int amount) {
		try {
			validate(amount);
		} catch(IllegalArgumentException ex) {
	 		amount *= -1;
	 	}
		overDraft = amount;
	}
	
	public int getOverDraft() {
		return overDraft;
	}
	@Override
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public int getBalance() {
		return balance;
	}
	
	// Transactions \\
	@Override
	public boolean withDrawal(int amount) {
		try {
		validate(amount);
		} catch(IllegalArgumentException ex) {
	 		amount *= -1;
	 	}
		
		if(validateTransaction(amount)) {
			balance -= amount;
			log.getTransfer("Withdraw", amount);
			return true;
		}
		return false;
	}

	@Override
	public boolean deposite(int amount) {
		try {
			validate(amount);
			} catch(IllegalArgumentException ex) {
		 		amount *= -1;
		 	}
		
		balance += amount;
		log.getTransfer("Deposit", amount);	
		return true;
	}
	
	@Override
	boolean validateTransaction(int amount) {	
		assert(amount >= 0);
	
			if((amount < overDraft) && (amount <= balance)) {
				return true;
				}
			else {
				return false;
			}
	}
	
	int validate(int amount) {
			if(amount >= 0) {
				return amount;
			} 
		throw new IllegalArgumentException();
	}

	public void exitAccount() {
		 AccountTable.updateBalance(accountNo, 1, balance);
	}
}
