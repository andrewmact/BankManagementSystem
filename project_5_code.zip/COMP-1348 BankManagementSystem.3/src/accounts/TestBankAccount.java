package accounts;

import accounts.CustomerAccount.CreditCard;
import bankException.InvalidAccountException;

abstract class TestBankAccount {
	
	//setUpBeforeTestClass 
	protected ChequingAccount getChequing() {
		return new ChequingAccount(0);
	}
	protected ChequingAccount getChequingOverDraftWith(int amount, int balance) {
		ChequingAccount account = new ChequingAccount(0);
						account.setOverDraft(amount);
						account.deposite(balance);
		return account;
	}
	protected ChequingAccount getChequingWith(int amount) {
		ChequingAccount account = new ChequingAccount(0);
						account.deposite(amount);
		return account;
	}
	protected SavingsAccount getSavings() {
		return new SavingsAccount(0);
	}
	protected SavingsAccount getSavingsMinimumWith(int amount, int balance) {
		SavingsAccount account = new SavingsAccount(0);
					   account.setMinBalance(amount);
					   account.deposite(balance);
		return account;
	}
	protected SavingsAccount getSavingsWith(int amount) {
		SavingsAccount account = new SavingsAccount(0);
					   account.deposite(amount);
		return account;
	}
	
	CreditCard getCard() {
		CustomerAccount account = new CustomerAccount();
		CreditCard credit = account.new CreditCard(0);
		return credit;
	}
	CreditCard getCardLimitWithSavingsAndChequing(int limit, int balance, int savingsMin, int chequingOverDraft, int savingsAmount, int chequingAmount) throws InvalidAccountException {
		CustomerAccount account = new CustomerAccount();
		account.createChequingAccount(chequingOverDraft);
		ChequingAccount checkAccount = account.getChequing();
		checkAccount.deposite(chequingAmount);
		account.createSavingsAccount(savingsMin);
		SavingsAccount saveAccount = account.getSavings();
		saveAccount.deposite(savingsAmount);
		
		CreditCard credit = account.new CreditCard(0);
		credit.setLimit(limit);
		credit.credit(balance);
		return credit;
	}
	CreditCard getCardLimitWith(int limit, int amount) {
		CustomerAccount account = new CustomerAccount();
		CreditCard credit = account.new CreditCard(0);
		credit.setLimit(limit);
		credit.credit(amount);
		return credit;
	}
	CreditCard getCardLimit(int limit) {
		CustomerAccount account = new CustomerAccount();
		CreditCard credit = account.new CreditCard(0);
		credit.setLimit(limit);
		return credit;
	}
	

	//setUpBeforeTestMethod
	 abstract void inheritanceTest();
	 abstract void getBalanceTest();
	 abstract void withDrawalTest();
	 abstract void depositeTest();
	 abstract void validateTransactionTest();
	//tearDownAfterTestMethod

	
	 //tearDownAfterTestClass
	 

}

