package accounts;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


class TestChequing extends TestBankAccount {
		ChequingAccount test;
		
		@Test
		void inheritanceTest() {
			test = getChequing();
				assertNotNull(test);
				assertEquals(true, test instanceof BankAccount);
		}

		@Test
		void getBalanceTest() {
			 test = getChequingWith(1000);
			 	assertNotNull(test);
			 	assertNotEquals(0, test.getBalance());
			 	assertEquals(1000, test.getBalance());
		}

		@Test
		void withDrawalTest() {
			 test = getChequingOverDraftWith(50, 500);
			 	assertEquals(true, test.withDrawal(0));
			 	assertEquals(true, test.withDrawal(49));
			 	assertEquals(false, test.withDrawal(50));
			 	assertEquals(451, test.getBalance());
		}

		@Test
		void depositeTest() {
			 test = getChequing();
			 	assertEquals(true, test.deposite(0));
			 	assertEquals(true, test.deposite(50));
			 	assertEquals(50, test.getBalance());
		}

		@Test
		void validateTransactionTest() {
			 test = getChequing();
			 	assertEquals(false, test.validateTransaction(0));
			 
			 test = getChequingOverDraftWith(50, 500);
			 	assertEquals(true, test.validateTransaction(0));
			 	assertEquals(true, test.validateTransaction(49));
			 	assertEquals(false, test.validateTransaction(50));
			 	
			 test = getChequingOverDraftWith(50, 25);
			 	assertEquals(true, test.validateTransaction(0));
			 	assertEquals(true, test.validateTransaction(25));
			 	assertEquals(false, test.validateTransaction(26));
		}
		
		@Test
		void testValidAmount() {
			 test = getChequing();
				assertEquals(0, test.validate(0));
				assertEquals(1, test.validate(1));
				
				boolean isIncorrect = false;
				try{
				test.validate(-1);
				} catch(IllegalArgumentException ex) {
					isIncorrect = true;
				}
				assertEquals(true, isIncorrect);
		}
		
}


