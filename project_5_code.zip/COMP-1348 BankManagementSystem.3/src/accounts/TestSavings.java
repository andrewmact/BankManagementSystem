package accounts;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestSavings extends TestBankAccount {
	SavingsAccount test;
	
	@Test
	void inheritanceTest() {
		test = getSavings();
			assertNotNull(test);
			assertEquals(true, test instanceof BankAccount);
	}

	@Test
	void getBalanceTest() {
		 test = getSavingsWith(1000);
		 	assertNotNull(test);
		 	assertNotEquals(0, test.getBalance());
		 	assertEquals(1000, test.getBalance());
	}

	@Test
	void withDrawalTest() {
		 test = getSavingsMinimumWith(400, 500);
		 	assertEquals(true, test.withDrawal(0));
		 	assertEquals(true, test.withDrawal(100));
		 	assertEquals(400, test.getBalance());
		 	
		 test = getSavingsMinimumWith(400, 500);
		 	assertEquals(true, test.withDrawal(10));
		 	assertEquals(false, test.withDrawal(91));
		 	assertEquals(490, test.getBalance());	 	
	}

	@Test
	void depositeTest() {
		 test = getSavings();
		 	assertEquals(true, test.deposite(0));
		 	assertEquals(true, test.deposite(50));
		 	assertEquals(50, test.getBalance());
	}

	@Test
	void validateTransactionTest() {
		 test = getSavings();
		 	assertEquals(false, test.validateTransaction(1));
		 
		 test = getSavingsMinimumWith(250, 500);
		 	assertEquals(true, test.validateTransaction(0));
		 	assertEquals(true, test.validateTransaction(250));
		 	assertEquals(false, test.validateTransaction(251));
	}
	
	@Test
	void testValidAmount() {
		 test = getSavings();
			assertEquals(0, test.validate(0));
			assertEquals(1, test.validate(1));
			
			boolean isIncorrect = false;
			try{
			test.validate(-1);
			} catch(IllegalArgumentException ex) {
				isIncorrect = true;
			}
			assertEquals(true, isIncorrect);
	}
}

