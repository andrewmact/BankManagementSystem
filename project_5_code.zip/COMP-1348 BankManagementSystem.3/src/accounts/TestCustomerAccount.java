package accounts;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import accounts.CustomerAccount.CreditCard;
import bankException.InvalidAccountException;
import bankException.InvalidPasswordException;

class TestCustomerAccount {
	
	CustomerAccount getCustomerAccount() {
		return new CustomerAccount();
	}
	CustomerAccount getCustomerAccountWith(int accountNo, String name, String password, String email) {
		try {
			return new CustomerAccount(accountNo, name, password, email);
		} catch (InvalidPasswordException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Test
	void testConstructor() {	
		CustomerAccount test = getCustomerAccountWith(1234567, "testName", "testPassword", "test@email.ca");
		assertNotNull(test);
	}

	@Test
	void testInheritance() {
		CustomerAccount test = getCustomerAccountWith(1234567, "testName", "testPassword", "test@email.ca");
		assertEquals(true, test instanceof Customer);
		assertEquals(1234567, test.getAccountNo());
		assertEquals("testName", test.getName());
		assertEquals("testPassword", test.getPassword());
	}

	@Test
	void testAccessSavings() throws InvalidAccountException {
		 CustomerAccount test = getCustomerAccount();
		 SavingsAccount sa = null;
		 assertEquals(true, test.createSavingsAccount(500));
		 assertNull(sa);
		
		 sa = test.getSavings();
		 assertNotNull(sa);
		 assertEquals(500, sa.getMinBalance());
		 
		
		 test.removeSavingsAccount(sa);
		 assertNotNull(sa);
		 
		 try {
			 sa = test.getSavings();
		 } catch(NullPointerException  e) {
			 assertEquals(e.getMessage(), "Savings account does not exist");
		 }
	}


	@Test
	void testAccessChequings() throws InvalidAccountException {
		 CustomerAccount test = getCustomerAccount();
		 ChequingAccount ca = null;
		 assertEquals(true, test.createChequingAccount(1000));
		 assertNull(ca);
		 
		 ca = test.getChequing();
		 assertNotNull(ca);
		 assertEquals(1000, ca.getOverDraft());
		 
		test.removeChequingAccount(ca);
		assertNotNull(ca);
			 
		try {
			ca = test.getChequing();
		} catch(NullPointerException  e) {
			assertEquals(e.getMessage(), "Chequing account does not exist");
		}
	}
	
	@Test
	void testAccessCredit() throws InvalidAccountException {
		 CustomerAccount test = getCustomerAccount();
		 CreditCard cc = null;
		 assertEquals(true, test.createCreditCard(500));
		 assertNull(cc);
		
		 cc = test.getCreditCard();
		 assertNotNull(cc);
		 assertEquals(500, cc.getLimit());
		 
		 test.removeCreditCard(cc);
		 assertNotNull(cc);
				 
		try {
			cc = test.getCreditCard();
		} catch(NullPointerException  e) {
			assertEquals(e.getMessage(), "Credit Card account does not exist");
		}
	}

	@Test
	void testIsNullAccount() {
		
	}


	@Test
	void testToString() {
		CustomerAccount test = getCustomerAccountWith(1234567, "testName", "testPassword", "test@email.ca");
		assertEquals("1234567", test.toString());
	}

}
