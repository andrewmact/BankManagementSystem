package accounts;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;

import bankException.InvalidPasswordException;

class TestCustomer {

	@Test
	public void testCustomer() throws InvalidPasswordException {
		Customer user = new Customer();
		
		assertNotNull(user.getAccountNo());
		assertNull(user.getName());
		assertNull(user.getPassword());
		
		
		Customer user2 = new Customer(123456, "Andrew", "123Password!", "andrewEmail@gamil.com");
		assertNotNull(user2.getAccountNo());
		assertNotNull(user2.getName());
		assertNotNull(user2.getPassword());
		
		assertEquals(123456, user2.getAccountNo());
		assertEquals("Andrew", user2.getName());
		assertEquals("123Password!", user2.getPassword());
	}

	@Test
	public void testChangePassword() throws InvalidPasswordException {
		Customer user = new Customer(123456, "Andrew", "123Password!", "andrewEmail@gamil.com");
		
		assertEquals("123Password!", user.getPassword());
		user.changePassword("123Password!", "Java!321");
		assertEquals("Java!321", user.getPassword());
	}
}
