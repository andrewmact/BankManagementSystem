package bankException;

public class InvalidBankFileException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public InvalidBankFileException(String message){
		super(message);
	}
	
	public InvalidBankFileException(String message, Throwable cause){
		super(message);
	}
}
