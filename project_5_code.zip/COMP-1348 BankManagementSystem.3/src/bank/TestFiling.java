package bank;

import accounts.ChequingAccount;
import accounts.CustomerAccount;
import bankException.InvalidAccountException;
import bankException.InvalidPasswordException;
import database.AccountTable;

public class TestFiling {

//	static CustomerAccount newAccount;
// 	static CustomerAccount loginAccount = new CustomerAccount();
// 	static BankLog bankLog = new BankLog();
// 	static Bank bank = new Bank();
//	
//	public static void main(String[] args) {
//		
//		int num = 0;
//		
//		try {
//			newAccount = bank.createNewAccount("test account", "testPassword", "myTestEmail@rrc.com");
//			//Writes into the password and email file
//			bankLog.log(newAccount);
//			num = newAccount.getAccountNo();
//		} catch (InvalidPasswordException e) {
//			e.printStackTrace();
//		}
//	
//			try {
//				//Reads the password file to verify if both the account number exists
//				//And if so it's value matches the attempted password
//				loginAccount = bankLog.dbLogin(loginAccount, num, "testPassword");
//			} catch (InvalidAccountException | InvalidPasswordException e1) {
//				e1.printStackTrace();
//			}
//			try {
//			ChequingAccount chequing = loginAccount.getChequing();
//							chequing.deposite(100);
//			AccountTable.updateBalance(loginAccount.getAccountNo(), 1, chequing.getBalance());
//			} catch(Exception e) {
//				e.printStackTrace();
//			}
//			
//		try {
//			//Change methods invoke the modify file methods. Updating the values to the correlating account number
//			loginAccount.changePassword("testPassword", "newTestPassword");
//			loginAccount.changeEmail("myTestEmail@rrc.com", "myNewEmail@rrc.com");
//		} catch (InvalidPasswordException e) {
//			e.printStackTrace();
//		}
//			try {
//				loginAccount = bankLog.logout(loginAccount);
//			} catch (InvalidAccountException e) {
//				e.printStackTrace();
//			}
//			
//			//Invoking the recover file methods
//			//These methods recover a accounts account number and email based off the users recover email.
//			bank.forgotAccount("myNewEmail@rrc.com");
//			
//			System.out.println("done");
//	}

}
