package bank;
/**
 * RecoverAccount: class implements Runnable which performs a action to recover a customers bank information
 * Class constructor takes the accounts email to return the accounts information too
 */
public class RecoverAccount implements Runnable{
	String email;
	BankLog bankLog;
	
	RecoverAccount(String email){
		this.email = email;
		bankLog = new BankLog();
	}
	/**
	 * run: executes code to retrive customer information
	 */
	@Override
	public void run() {
		String accountInfo = bankLog.recoverAccount(email);
		 System.out.println(accountInfo);
	}
	
}
