package bank;

import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.ThreadLocalRandom;
import accounts.CustomerAccount;
import bankException.InvalidAccountException;
import bankException.InvalidBankFileException;
import bankException.InvalidPasswordException;
import database.CustomerTable;
import file.FileConnection;

public class BankLog {

	public static Accounts<CustomerAccount> accounts = new Accounts<CustomerAccount>();	
	public static ConcurrentSkipListSet<Integer> accountIDs = new ConcurrentSkipListSet<Integer>();

	//generic class
	static	{
		//accounts list is set to a synchronizedList for thread safty
		accounts.setAccounts(Collections.synchronizedList(new ArrayList<CustomerAccount>()));
	}
	
	void log(CustomerAccount account) {
		assert (account != null);
		
		int num = account.getAccountNo();
		String name = account.getName();
		String password = account.getPassword();
		String email = account.getEmail();
		//generic class add
		if(accounts.add(account)) {
			FileConnection.writeInPasswordFile(num, password);
			FileConnection.writeInEmailFile(num, email);
			CustomerTable.insert(num, name, password, email);
		}
	}
	
	public CustomerAccount dbLogin(CustomerAccount account) throws InvalidAccountException, InvalidPasswordException {										
				CustomerAccount checkAccount = null;
				boolean loggedIn = false;
				try {					
					    checkAccount = accounts.search(account);
					  
					 if(checkAccount.getPassword().equals(account.getPassword())){  
						 loggedIn = accounts.logIn(account); //generic class remove
					 } else {
						throw new InvalidPasswordException("Password does not match");
					 }
					 
					 if(loggedIn) {
						 return checkAccount;
					 }
					 
					 throw new InvalidAccountException("Cannot enter account, account is already logged in");
				} catch (Exception e) {
					throw new InvalidAccountException("Unable to login into account", e.getCause());
				}
	}
	
	boolean removeAccount(CustomerAccount account){
		int accountNo = account.getAccountNo();
		try {
		   FileConnection.removeAccountPassword(accountNo, account.getPassword());
		   FileConnection.removeAccountEmail(accountNo, account.getEmail());
		   return true;
		}
		catch(InvalidBankFileException e) {
			System.out.println(e.getMessage());
			return false;
		}
	}
	
	String recoverAccount(String email) {
			 try {
				String accountNo = FileConnection.recoverAccount(email);
				String password = FileConnection.recoverPassword(accountNo);
					return accountNo+" "+password;
			} catch (InvalidAccountException | InvalidBankFileException e) {
				e.printStackTrace();
				return "Account unable to be recovered";
			}	
	}
	/**
	 * @return: null, now loginAccount variable is not a user account
	 * @throws InvalidAccountException 
	 */
	CustomerAccount logout(CustomerAccount account) throws InvalidAccountException {
		//generic class add
		boolean updated = accounts.add(account);
		if(updated) {
		return null;
		} else {
			throw new InvalidAccountException("Error");
		}
	}
	
	/**
	 * @param accountNo: users bank account number
	 * @return: true if the account number entered is seven digits
	 * 		    false if the account number is larger or smaller than what it should be
	 * 
	 * @throws InvalidAccountException: throw if the account number is not seven digits. This means the user entered an invalid amount of digits fot their account number
	 */
	boolean validAccountNumber(int accountNo) throws InvalidAccountException {
			if(String.valueOf(accountNo).length() == 7) {
				return true;
			}
				throw new InvalidAccountException("Account number must be 7 digits long");
	}
	/**
	 * @param user: customer account that matched users entered account number
	 * @param password: users entered password
	 * @return: true if the users entered password matchs the accounts password
	 * 			false if the users entered password does not match the accounts password
	 * 
	 * @throws InvalidPasswordException: throw if the password and accounts password do not match
	 */
	boolean validPassword(String password) throws InvalidPasswordException {
		if(password.length() > 7) {
			return true;
		} 
			throw new InvalidPasswordException("Password does meet the requied length");
	}
	/**
	 * @return a seven digit number
	 * 
	 * rnd.nextInt(9999999): creates a random 7 digit number
	 *  !(accountNumber.contains(accountNo): checks to see if the list of account numbers does not contain the randomly generated account number
	 *  if this is true: add the account number to the list of used account numbers
	 *  		   false: do nothing
	 */
	int generateAccountNumber() {
	
		while(true) {	  		 
			 int accountNo = ThreadLocalRandom.current().nextInt(9999999);
			if(accountNo > 999999 && accountNo < 10000000) {
				 //concurrency
					if(accountIDs.isEmpty() || accountIDs.contains(accountNo)) {
							accountIDs.add(accountNo);
						}
							return accountNo;
			}
		}
	}
	
	
	
	
	
	
}	
	
	
	
	
	

