package bank;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import bankException.InvalidAccountException;
import bankException.InvalidBankFileException;
import bankException.InvalidPasswordException;
import file.FileConnection;

class TestFileConnection {

	FileConnection file;
	
	FileConnection get() {
		return new FileConnection();
	}
	
	@Test
	void constructor() {
		file = get();
		assertNotNull(file);
	}

	@Test
	void testWriteFile() {
		file = get();
		boolean isIn;
			isIn = FileConnection.writeInPasswordFile(1234567, "123Password");
			assertEquals(true, isIn);
		
			isIn = FileConnection.writeInEmailFile(1234567, "test@email.com");
			assertEquals(true, isIn);
	}

	@Test
	void testReadFile() throws InvalidBankFileException {
		file = get();
		boolean isCorrect;
		try {
			isCorrect =	FileConnection.readFromPasswordFile(1234567, "123Password");
			assertEquals(true, isCorrect);
		}
		catch(InvalidAccountException a) {}
		catch(InvalidPasswordException p) {}
	
		try {
			isCorrect =	FileConnection.readFromEmailFile(1234567, "test@email.com");
			assertEquals(true, isCorrect);
		} catch (InvalidAccountException e) {}
	
	}
 
	
	
	@Test
	void testModify() throws InvalidBankFileException, IOException {
		file = get();
		boolean isCorrect = false;
		
		FileConnection.modifyPasswordFile(1234567,"newPassword");
		FileConnection.modifyEmailFile(1234567, "email@test.com");
		
			
			try {
				isCorrect =	FileConnection.readFromPasswordFile(1234567, "newPassword");
				assertEquals(true, isCorrect);
			}
			catch(InvalidAccountException a) {}
			catch(InvalidPasswordException p) {}
		
			try {
				isCorrect =	FileConnection.readFromEmailFile(1234567, "email@test.com");
				assertEquals(true, isCorrect);
			} catch (InvalidAccountException e) {}
	}
	
	@Test
	void testRecover() throws InvalidAccountException, InvalidBankFileException {
		file = get();
			String account = FileConnection.recoverAccount("email@test.com");
			int number = Integer.parseInt(account);
			assertEquals(1234567, number);
		
			String password = FileConnection.recoverPassword("1234567");
			assertEquals("newPassword", password);
	}
	
	@Test
	void testRemove() {
		file = get();
		
		try {
		FileConnection.removeAccountPassword(1234567, "newPassword");
		FileConnection.removeAccountEmail(1234567, "email@test.com");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			FileConnection.readFromPasswordFile(1234567, "newPassword");
		} catch(Exception e) {
			String error = e.getMessage();
			assertEquals("Account not found", error);
		}
		
		try {
			FileConnection.readFromEmailFile(1234567, "email@test.com");
		} catch(Exception e) {
			String error = e.getMessage();
			assertEquals("Account not found", error);
		}
	}
	
}
