package bank;

import accounts.ChequingAccount;
import accounts.CustomerAccount;
import bankException.InvalidAccountException;
import bankException.InvalidPasswordException;
import database.AccountTable;

public class TestTransactionTable {
 
//	static CustomerAccount newAccount;
// 	static CustomerAccount loginAccount;
// 	static BankLog bankLog = new BankLog();
// 	static Bank bank = new Bank();
// 	
//	//Classes: CustomerAccount
// 
// 	//Used to demonstrate how the TransactionTable is interacted with 
//	public static void main(String[] args) {
//			int number = 0;
//			try {
//				newAccount = bank.createNewAccount("Andre", "drodssap321", "test@email.ca");
//				bankLog.log(newAccount);
//				number = newAccount.getAccountNo();
//			} 
//			catch (InvalidPasswordException e1) {
//				e1.printStackTrace();
//			}
//			
//			try {
//				loginAccount = bankLog.dbLogin(loginAccount, number, "drodssap321");
//				}
//				catch(Exception e) {
//					e.printStackTrace();
//				}
//				
//			loginAccount.createSavingsAccount(500);
//			loginAccount.createCreditCard(500);
//			
//	try {
//		System.out.println("\nChequing Account "+loginAccount.getAccountNo());
//		ChequingAccount chequing = loginAccount.getChequing();
//		
//		//Insert into Transaction table
//					    chequing.deposite(2000);
//					    chequing.withDrawal(100);	   
//				AccountTable.updateBalance(loginAccount.getAccountNo(), 1, chequing.getBalance());
//			}
//			catch(Exception e) {
//				e.printStackTrace();
//			}
//
//
//	}

}

