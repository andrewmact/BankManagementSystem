package bank;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import accounts.ChequingAccount;
import accounts.CustomerAccount;
import accounts.CustomerAccount.CreditCard;
import accounts.SavingsAccount;
import bankException.InvalidAccountException;
import bankException.InvalidPasswordException;
import database.AccountTable;
import database.CustomerTable;

public class Bank {

	static CustomerAccount newAccount;
 	static CustomerAccount loginAccount = new CustomerAccount();
 	static BankLog bankLog = new BankLog();
 	static Bank bank = new Bank();
 	
	public static void main(String[] args) {
		
		int threads = Runtime.getRuntime().availableProcessors();
		ExecutorService ex = Executors.newFixedThreadPool(threads);
		
		int num = -1;		
		try {
			
			CreateAccount user1 = new CreateAccount("test account", "testPassword", "myTestEmail@rrc.com");
			Future <CustomerAccount> account = ex.submit(user1);
			
				System.out.println("Create account");
			
				newAccount = account.get();
				System.out.println(newAccount.getAccountNo());
				System.out.println(newAccount.getName());
				System.out.println(newAccount.getPassword());
				System.out.println(newAccount.getEmail());
				num = newAccount.getAccountNo();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {			
			LogInAccount user = new LogInAccount(num, "testPassword");
			Future <CustomerAccount> account = ex.submit(user);
			loginAccount = account.get();
			
			System.out.println("Login account");
			
			System.out.println(loginAccount.getAccountNo());
			System.out.println(loginAccount.getName());
			System.out.println(loginAccount.getPassword());
			System.out.println(loginAccount.getEmail());
			
			loginAccount.createSavingsAccount(0);
			
			SavingsAccount sa = loginAccount.getSavings();
						   sa.deposite(500);
						   sa.withDrawal(500);
						   sa.exitAccount();
	
			loginAccount = bankLog.logout(loginAccount); //log out
			
		} catch (InterruptedException | ExecutionException e1) {
			e1.printStackTrace();
		} catch (InvalidAccountException e) {
			e.printStackTrace();
		} finally {
			
		}
			
		System.out.println("Recover account");
		RecoverAccount recover = new RecoverAccount("myTestEmail@rrc.com");
					   ex.execute(recover);
		
		
		try {
			LogInAccount user = new LogInAccount(num, "testPassword");
			Future <CustomerAccount> account = ex.submit(user);
			loginAccount = account.get();
			
			SavingsAccount sa = loginAccount.getSavings();
						  System.out.println(sa.getBalance());
			
			DeleteAccount delete1 = new DeleteAccount(loginAccount);
			Future<CustomerAccount> deleted = ex.submit(delete1);
			loginAccount = deleted.get();
			
			loginAccount.getName();
		} catch(InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		
		
		
		 ex.shutdown();
		 try {
			 ex.awaitTermination(2 , TimeUnit.SECONDS);
		 } catch(InterruptedException e) {
			 e.printStackTrace();
		 }
		 finally{
			 if(!ex.isTerminated()) {
				 List<Runnable> unFinnished = ex.shutdownNow();
			 }
		 }
			System.out.println("done");
	}//END MAIN
	
}//END CLASS
