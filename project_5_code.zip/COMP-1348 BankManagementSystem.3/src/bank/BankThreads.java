package bank;

import java.util.concurrent.Callable;
import accounts.CustomerAccount;
import bank.BankLog;
import bankException.InvalidAccountException;
import bankException.InvalidBankFileException;
import bankException.InvalidPasswordException;
import database.AccountTable;
import database.CustomerTable;

public class BankThreads {
//	BankLog bankLog = new BankLog();
//		
///**
// * CreateAccount class: This class implements Callable which is used to create and return a Customer Account
// * This class gathers varibales through its constructo which is neccessary to create a customer account
// */
// static	class CreateAccount implements Callable<CustomerAccount> {
//	 
//	 	BankLog bankLog;
//		CustomerAccount account;
//		String name;
//		String password;
//		String email;
//		
//		CreateAccount(String name, String password, String email){
//			this.name = name;
//			this.password = password;
//			this.email = email;
//			bankLog = new BankLog();
//		}
//		/**
//		 * call: is invoked and ran in a thread
//		 * Functions: The call method generates a account number
//		 * 			  The call method then creates an instance of a Customer Account
//		 * 			  This account is then logged into the bank log
//		 * @return: the created customer account is returned 
//		 */
//		@Override
//		public CustomerAccount call() throws InvalidPasswordException {
//			int accountNo = bankLog.generateAccountNumber();
//			 
//			try {
//				account = new CustomerAccount(accountNo, name, password, email);
//				bankLog.log(account);
//				
//				return account;
//			} catch(InvalidPasswordException ex) {
//				throw new InvalidPasswordException("Unable to create an account", ex.getCause());
//			}
//		}
//		
//		
//	} //END OF CREATE ACCOUNT
///**
// * LogInAccount: this class implements Callable which is used to perform actions to find and return a Customer Account
// * This class uses its constructor to gather the necessary variables to find and access a customer account
// */
// static	class LogInAccount implements Callable<CustomerAccount> {
//	 
//			BankLog bankLog;
//			CustomerAccount account;
//			int accountNo;
//			String password;
//		
//		LogInAccount(int accountNo, String password){
//			this.accountNo = accountNo;
//			this.password = password;
//			bankLog = new BankLog();
//		}
//		/**
//		 * call: is invoked and ran in a thread
//		 * Function: call first creates a customer account from the users entered account number and password
//		 * 			 The purpose of this is to compare the users entered data to the stored customer accounts
//		 * 			 The call method validates that the users ented account number meets the minimum requirments
//		 * 			 The account then invokes the bankLog login method to search through the accounts list which contains customer account objects
//		 * 			 If no exceptions are throughn the account has been successfully accessed and will invoke the Accounts Table in the bank database to access account information
//		 * 	@return: The users requested bank account
//		 * 
//		 * @exception: InvalidAccountException is thrown if a exception is thrown when validating the customers account or when logging int the customers account
//		 * @exception: InvlaidPasswordException is through if a exception occurs with the banklog login method
//		 */
//		@Override
//		public CustomerAccount call() throws InvalidAccountException, InvalidPasswordException {
//			
//			try {
//				account = new CustomerAccount(accountNo, password);
//			} catch (InvalidPasswordException e) {
//				e.printStackTrace();
//			}
//			try {
//				if(bankLog.validAccountNumber(accountNo)) {
//					account = bankLog.dbLogin(account);
//				}
//				account = AccountTable.getAccount(account, account.getAccountNo());
//				return account;
//			} 
//			catch(InvalidAccountException ex) {
//				throw new InvalidAccountException("Unable to login into account", ex.getCause());
//			} 
//			catch (InvalidPasswordException ex) {
//				throw new InvalidPasswordException("Unable to login into account", ex.getCause());
//			}
//		}
//		
//	}//END OF LOGIN
// /**
//  * DeleteAccount: implements Callable which is used to delete a customer account
//  * This class uses its constructor to receive a customer account to delete
//  * Since this class receives a customer account. The account must be logged into before it can be properly deleted
//  */
// static class DeleteAccount implements Callable<CustomerAccount> {
//	 CustomerAccount account;
//	 BankLog bankLog;
//	 
//	 DeleteAccount(CustomerAccount account){
//		 this.account = account;
//		 bankLog = new BankLog();
//	 }
//	/**
//	 *  call: is invoked and ran in a thread
//	 *  Function: This call method attempts to perform 3 different remove account methods
//	 *  		  The variable accounts helps record if a account is removed or does not exist
//	 *  		  To properly delete a customer account. The call method must first attempt to remove any bank accounts the account may hold
//	 *  		  If this can be done the account will tic one number off the accounts counter.
//	 *  		  OR if this account does not exist and an exception is thrown the method will tic one number off of the accounts counter in the nullpointerexception catch
//	 *  		  Once all bank accounts are removed. The account is removed from banklog records (Which access the storage file) and the database.
//	 *  		  Then the account is turned to null and returned to the bank.
//	 *  		
//	 */
//	@Override
//	public CustomerAccount call() throws Exception {
//		String removed ="";
//		int accounts = 3;
//		int accountNo = account.getAccountNo();
//		
//		 try {
//			account.removeCreditCard(account.getCreditCard());
//			accounts -= 1;
//		 } 
//		 catch (NullPointerException e) {accounts -= 1;}//account does not exist 
//		 catch (InvalidAccountException e) { removed+="Unable to remove Credit Card"; }
//		
//		 
//		 try {
//			account.removeChequingAccount(account.getChequing());
//			accounts -= 1;
//		}
//		catch (NullPointerException e) {accounts -= 1;}//account does not exist 
//		catch (InvalidAccountException e) { removed+="\nUnable to remove Chequing Account"; }
//		 
//		 try {
//			account.removeSavingsAccount(account.getSavings());
//			accounts -= 1;
//		 }
//		 catch (NullPointerException e) {accounts -= 1;}//account does not exist 
//		 catch (InvalidAccountException e) {
//			removed+="\nUnable to remove Savings Account";
//		 }
//		 
//		if(accounts == 0) {
//			if(bankLog.removeAccount(account)) {
//				CustomerTable.deleteAccount(accountNo);
//				return null;
//			}
//		}
//		System.out.println("Bank account not removed\n"+removed);
//		return account;
//	}
//	/**
//	 * RecoverAccount: class implements Runnable which performs a action to recover a customers bank information
//	 * Class constructor takes the accounts email to return the accounts information too
//	 */
//	static class RecoverAccount implements Runnable{
//		String email;
//		BankLog bankLog;
//		
//		RecoverAccount(String email){
//			this.email = email;
//			bankLog = new BankLog();
//		}
//		/**
//		 * run: executes code to retrive customer information
//		 */
//		@Override
//		public void run() {
//			String accountInfo = bankLog.recoverAccount(email);
//			 System.out.println(accountInfo);
//		}
//		
//	}
//	
//	 
// }
}