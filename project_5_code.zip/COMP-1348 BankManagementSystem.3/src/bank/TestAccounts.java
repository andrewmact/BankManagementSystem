package bank;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import accounts.Customer;
import accounts.CustomerAccount;
import bankException.InvalidPasswordException;

class TestAccounts {
	
	static List<CustomerAccount> accountNumber = new ArrayList<CustomerAccount>();
	
	
	static void loadAccount() throws InvalidPasswordException {
	CustomerAccount c1 = new CustomerAccount(1111111, "customer 1", "password1", "email1");
	CustomerAccount c3 = new CustomerAccount(3333333, "customer 3", "password3", "email3");
	CustomerAccount c7 = new CustomerAccount(7777777, "customer 7", "password7", "email7");
	CustomerAccount c5 = new CustomerAccount(5555555, "customer 5", "password5", "email5");
	CustomerAccount c2 = new CustomerAccount(2222222, "customer 2", "password2", "email2");
	CustomerAccount c6 = new CustomerAccount(6666666, "customer 6", "password6", "email6");
	CustomerAccount c4 = new CustomerAccount(4444444, "customer 4", "password4", "email4");
	
	accountNumber.add(c4);
	accountNumber.add(c1);
	accountNumber.add(c3);
	accountNumber.add(c7);
	accountNumber.add(c5);
	accountNumber.add(c6);
	accountNumber.add(c2);

	}
	
	@Test
	void testConstructor() {
		Accounts<Customer> test1 = new Accounts<Customer>();
		assertNotNull(test1);
	}
	
	@Test
	void testAdd() throws InvalidPasswordException {
		loadAccount();
		Accounts<CustomerAccount> test = new Accounts<CustomerAccount>();
		test.setAccounts(accountNumber);
		CustomerAccount c1 = new CustomerAccount(1111111, "customer 1", "password1", "email1");
		
		boolean isAdded = test.add(c1);
		assertEquals(true, isAdded);
	}
	
	@Test
	void testSearch() throws Exception {
	 Accounts<CustomerAccount> testAccounts = new Accounts<CustomerAccount>();
	 						   testAccounts.setAccounts(accountNumber);
	
	  CustomerAccount testVar = new CustomerAccount(5555555, "password5");
	  CustomerAccount testVar2 = new CustomerAccount(666666, "password6");
	  CustomerAccount received = testAccounts.search(testVar);
	  	
	  assertEquals(testVar, received);
	  assertNotEquals(testVar2, received);
	
	}

}
