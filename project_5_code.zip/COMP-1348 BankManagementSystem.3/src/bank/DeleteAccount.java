package bank;

import java.util.concurrent.Callable;

import accounts.CustomerAccount;
import bankException.InvalidAccountException;
import database.CustomerTable;

/**
* DeleteAccount: implements Callable which is used to delete a customer account
* This class uses its constructor to receive a customer account to delete
* Since this class receives a customer account. The account must be logged into before it can be properly deleted
*/
public class DeleteAccount implements Callable<CustomerAccount> {
		 CustomerAccount account;
		 BankLog bankLog;
		 
		 DeleteAccount(CustomerAccount account){
			 this.account = account;
			 bankLog = new BankLog();
		 }
		/**
		 *  call: is invoked and ran in a thread
		 *  Function: This call method attempts to perform 3 different remove account methods
		 *  		  The variable accounts helps record if a account is removed or does not exist
		 *  		  To properly delete a customer account. The call method must first attempt to remove any bank accounts the account may hold
		 *  		  If this can be done the account will tic one number off the accounts counter.
		 *  		  OR if this account does not exist and an exception is thrown the method will tic one number off of the accounts counter in the nullpointerexception catch
		 *  		  Once all bank accounts are removed. The account is removed from banklog records (Which access the storage file) and the database.
		 *  		  Then the account is turned to null and returned to the bank.
		 *  		
		 */
		@Override
		public CustomerAccount call() throws Exception {
			String removed ="";
			int accounts = 3;
			int accountNo = account.getAccountNo();
			
			 try {
				account.removeCreditCard(account.getCreditCard());
				accounts -= 1;
			 } 
			 catch (NullPointerException e) {accounts -= 1;}//account does not exist 
			 catch (InvalidAccountException e) { removed+="Unable to remove Credit Card"; }
			
			 
			 try {
				account.removeChequingAccount(account.getChequing());
				accounts -= 1;
			}
			catch (NullPointerException e) {accounts -= 1;}//account does not exist 
			catch (InvalidAccountException e) { removed+="\nUnable to remove Chequing Account"; }
			 
			 try {
				account.removeSavingsAccount(account.getSavings());
				accounts -= 1;
			 }
			 catch (NullPointerException e) {accounts -= 1;}//account does not exist 
			 catch (InvalidAccountException e) {
				removed+="\nUnable to remove Savings Account";
			 }
			 
			if(accounts == 0) {
				if(bankLog.removeAccount(account)) {
					CustomerTable.deleteAccount(accountNo);
					return null;
				}
			}
			System.out.println("Bank account not removed\n"+removed);
			return account;
		}
}	
