package bank;

import accounts.ChequingAccount;
import accounts.CustomerAccount;
import bankException.InvalidAccountException;
import bankException.InvalidPasswordException;
import database.AccountTable;

public class TestAccountTable {

//	static CustomerAccount newAccount;
// 	static CustomerAccount loginAccount;
// 	static BankLog bankLog = new BankLog();
// 	static Bank bank = new Bank();
//	
//	//Classes: CustomerAccount
// 	
//	//Used to demonstrate how the AccountTable is interacted with 
//	public static void main(String[] args) {
//			int number = 0;
//			try {
//					bank.createNewAccount("Andrew", "123PassW0rd", "test@email.ca");
//					number = newAccount.getAccountNo();
//			} 
//			catch (InvalidPasswordException e1) {
//				e1.printStackTrace();
//			}
//		
//			try {
//				loginAccount = bankLog.dbLogin(loginAccount, number, "123PassW0rd");
//				}
//				catch(Exception e) {
//					e.printStackTrace();
//				}
//	//Insert into Account table		
//		loginAccount.createSavingsAccount(500);
//		loginAccount.createCreditCard(500);
//		
//		try {
//			System.out.println("\nChequing Account "+loginAccount.getAccountNo());
//			
//	//Update last logged in into Account table	
//		ChequingAccount chequing = loginAccount.getChequing();
//					    chequing.deposite(2000);
//					    chequing.withDrawal(100);	   
//				System.out.println("Chequing account balance: "+chequing.getBalance());
//				
//	//Update balance in Account Table			
//				AccountTable.updateBalance(loginAccount.getAccountNo(), 1, chequing.getBalance());
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//			
//		try {
//			ChequingAccount chequing = loginAccount.getChequing();
//			loginAccount.removeChequingAccount(chequing);
//		} catch(InvalidAccountException e) {
//			ChequingAccount chequing = loginAccount.getChequing();
//			chequing.setOverDraft(2000);
//		//	chequing.withDrawal(1900);
//			try {
//				
//	//Delete account in Account Table	
//				loginAccount.removeChequingAccount(chequing);
//				ChequingAccount chequing2 = loginAccount.getChequing();
//			} catch (InvalidAccountException e1) {
//				e1.printStackTrace();
//			}
//			
//		}
//
//	}

}
