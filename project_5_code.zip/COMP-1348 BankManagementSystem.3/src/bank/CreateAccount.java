package bank;

import java.util.concurrent.Callable;

import accounts.CustomerAccount;
import bankException.InvalidPasswordException;
/**
* CreateAccount: this class implements Callable which is used to perform actions to create and return a Customer Account
* This class uses its constructor to gather the necessary variables to create a customer account
*/
public class CreateAccount implements Callable<CustomerAccount> {
	 
 	BankLog bankLog;
	CustomerAccount account;
	String name;
	String password;
	String email;
	
	CreateAccount(String name, String password, String email){
		this.name = name;
		this.password = password;
		this.email = email;
		bankLog = new BankLog();
	}
	/**
	 * call: is invoked and ran in a thread
	 * Functions: The call method generates a account number
	 * 			  The call method then creates an instance of a Customer Account
	 * 			  This account is then logged into the bank log
	 * @return: the created customer account is returned 
	 */
	@Override
	public CustomerAccount call() throws InvalidPasswordException {
		int accountNo = bankLog.generateAccountNumber();
		 
		try {
			account = new CustomerAccount(accountNo, name, password, email);
			bankLog.log(account);
			
			return account;
		} catch(InvalidPasswordException ex) {
			throw new InvalidPasswordException("Unable to create an account", ex.getCause());
		}
	}
	

}
