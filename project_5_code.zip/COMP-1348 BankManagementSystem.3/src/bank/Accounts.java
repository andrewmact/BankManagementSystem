package bank;

import java.util.List;
import accounts.Customer;

public class Accounts<T extends Customer> {
	
	List<T> accounts;
	/**
	 * setAccount: used to set the List Type for the Accounts object. This List will hold account objects for the instance
	 * @param accounts: type of List the instance will use. Must be the same type as the instance
	 */
	protected void setAccounts(List<T> accounts) {
		this.accounts = accounts;
	}
	/**
	 * add: adds a same object type to the instances List
	 * @param account: the object being added to the List
	 * @return: true if the object is added
	 * 			false if the object is not added
	 */
	protected boolean add(T account) {
		return accounts.add(account);
	}
	/**
	 * login: if invoked the object the user wishes to access will be taken out of the list
	 * 			This prevents any other users from logging into the account
	 * @param account: the account object the user wishes to access
	 * @return: true if the account was able to be accessed by the user
	 * 			false if the account is not found in the accounts list
	 */
	boolean logIn(T account) {
		return accounts.remove(account);
	}
	/**
	 * search: looks in the account list for the account object the user wants to access
	 * @param account: the object the user wants to access
	 * @return: the object the user wants to access
	 * @throws Exception: an exception is thrown if the account object can not be found
	 * 
	 * The method compares objects based on if the account is an instance of a Customer 
	 * and if the account number entered matches a account number in the accounts list
	 */
	public T search(T account) throws Exception {	
		sortAccounts();
		
		for(T acn : accounts) {
			if((account instanceof Customer) && (account.equals(acn))) {
				return acn;
			}
		}
		throw new Exception("Account not found");
	}
	/**
	 * sortAccounts: sorts the list of accounts based off of the objects hashcode. 
	 * 				This is done by passing a lambda which evaluates if one hascode number is larger from the other
	 * 				This sorts my list of accounts by the size of their hashcode.
	 * 				Which for my code is the Accounts account number.
	 */
	protected void sortAccounts() {
		accounts.sort((o1, o2)->{
			return (o1.hashCode() - o2.hashCode());
		});
	}
	
	
}

