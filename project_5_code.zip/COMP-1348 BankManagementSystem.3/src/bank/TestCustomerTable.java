package bank;

import accounts.CustomerAccount;
import bankException.InvalidAccountException;
import bankException.InvalidPasswordException;

public class TestCustomerTable {
	
//	static CustomerAccount newAccount;
// 	static CustomerAccount loginAccount;
// 	static BankLog bankLog = new BankLog();
// 	static Bank bank = new Bank();
// 	
// 	//Classes: BankLog, Customer
// 	
// 	//Used to demonstrate how the CustomerTable is interacted with 
//	public static void main(String[] args) {
//	
//		//INSERT into customer table
//		int number = 0;
//		try {
//			newAccount = bank.createNewAccount("Mr java", "NfT67yy?", "test@email.ca");
//			number = newAccount.getAccountNo();
//			//Inserts customer information into customer table
//			bankLog.log(newAccount);
//		} catch (InvalidPasswordException e1) {
//			e1.printStackTrace();
//		}
//		
//			try {
//				loginAccount = bankLog.dbLogin(loginAccount, number, "NfT67yy?");
//				}
//				catch(Exception e) {
//					e.printStackTrace();
//				}
//				
//
//		//UPDATE into customer table
//		try {
//			//updates password information
//			loginAccount.changePassword("NfT67yy?", "123JavaTest!");
//		} catch(InvalidPasswordException e) {
//			e.printStackTrace();
//		}
//
//		//DELETE a customer account in a customer table
//		try {
//			//deletes account
//			loginAccount =	bank.deleteAccount(loginAccount);
//			} catch (InvalidAccountException e) {
//				e.printStackTrace();
//			}
//			
//	}

}
