package bank;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import accounts.ChequingAccount;
import accounts.CustomerAccount;
import bankException.InvalidAccountException;
import bankException.InvalidPasswordException;

class TestBank {

//	@Test
//	void constructor() {
//		Bank bank = new Bank();
//		assertNotNull(bank);
//	}
//	
//	@Test
//	void createAccount() throws InvalidPasswordException{
//		Bank bank = new Bank();
//		BankLog log = new BankLog();
//		CustomerAccount user = new CustomerAccount(1234567, "test", "test1234", "test@email.ca");
//						log.log(user);
//		
//		assertNotNull(user);
//	}
//	@Test
//	void accessBankLog() {
//		
//	}
//	@Test
//	void accessDataBase() {
//		
//	}
//	@Test
//	void testCreateNewAccount() {
//		Bank bank = new Bank();
//		
//		CustomerAccount test = null;
//		String name = "Java";
//		String password = "123P@ssWord";
//		String email = "test@email.ca";
//
//		assertNull(test);
//		try {
//			bank.createNewAccount(name, password, email);
//		} catch (InvalidPasswordException e) {
//			e.printStackTrace();
//		}
//	
//	}
//
//	@SuppressWarnings("unused")
//	@Test
//	void testDeleteAccount() throws InvalidAccountException, InvalidPasswordException {
//		Bank bank = new Bank();
//		BankLog system = new BankLog();
//		CustomerAccount test = null;
//		String name = "Java";
//		String password = "123P@ssWord";
//		String email = "test@email.ca";
//		
//		//Create the account
//			try {
//				system.log(new CustomerAccount(1234567, name, password, email));
//			} catch (InvalidPasswordException e) {
//				e.printStackTrace();
//			}
//				system.dbLogin(test, 1234567, password);
//			    assertNotNull(test); //Acount exists
//		
//		//Delete the account
//			try {
//				bank.deleteAccount(test);
//			} catch (InvalidAccountException e) {
//				e.printStackTrace();
//			}
//				assertNotNull(test); //variable does not register deletion
//				assertEquals(name, test.getName());
//				
//		//Attempt to access chequings account unsuccessful
//				try {
//				ChequingAccount ca = test.getChequing();
//				} catch (NullPointerException e) {
//					assertEquals(e.getMessage(), "Chequing account does not exist");
//				}
//		//Account not able to be signed in
//				test = null;
//			try {
//				test = system.dbLogin(test, 1234567, password);
//			} catch (Exception e) {
//				assertEquals(e.getMessage(), "No Account Found");
//			}
//			
//		
//	}

}
