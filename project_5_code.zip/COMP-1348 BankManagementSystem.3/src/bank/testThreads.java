package bank;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import accounts.CustomerAccount;

class testThreads {

	
	@Test
	void testConstruct() {
		BankThreads bt = new BankThreads();
		assertNotNull(bt);
	}

	@Test
	void testCreateAccount() {
		CreateAccount ca = new CreateAccount("testName", "testPassword", "testEmail");
		CustomerAccount test = null;
		
		try {
			test = ca.call();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(test.getName(), "testName");
		assertEquals(test.getPassword(), "testPassword");
		assertEquals(test.getEmail(), "testEmail");
	}
	
	@Test
	void testLogInAccount() {
		CreateAccount ca = new CreateAccount("testName2", "testPassword2", "testEmail2");
		int number = 0;
		CustomerAccount test = null;
		CustomerAccount test2 = null;
		
		try {
			test = ca.call();
			number = test.getAccountNo();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		LogInAccount la = new LogInAccount(number, "testPassword2");
		
		try {
			test2 = la.call();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(test, test2);
		assertEquals(test.getAccountNo(), test2.getAccountNo());
		assertEquals(test.getPassword(), test2.getPassword());
		
	}
	
	@Test
	void testDeleteAccount() {
		CreateAccount ca = new CreateAccount("testName3", "testPassword3", "testEmail3");
		int number = 0;
		CustomerAccount test = null;
		CustomerAccount test2 = null;
		
		try {
			test = ca.call();
			number = test.getAccountNo();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		DeleteAccount da = new DeleteAccount(test);
		
		try {
			test = da.call();
		} catch(Exception e) {
			e.printStackTrace();
		}
		assertNull(test);
		assertEquals(null, test);
	}
	
	@Test
	void testRecoverAccount() {
		CreateAccount ca = new CreateAccount("testName4", "testPassword4", "testEmail4");
		int number = 0;
		CustomerAccount test = null;
		
		try {
			test = ca.call();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		RecoverAccount ra = new RecoverAccount("testEmail4");
					   ra.run();
		
	}
	
}
