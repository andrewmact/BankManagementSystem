package bank;

import java.util.concurrent.Callable;

import accounts.CustomerAccount;
import bankException.InvalidAccountException;
import bankException.InvalidPasswordException;
import database.AccountTable;

/**
* LogInAccount: this class implements Callable which is used to perform actions to find and return a Customer Account
* This class uses its constructor to gather the necessary variables to find and access a customer account
*/
public class LogInAccount implements Callable<CustomerAccount> {
	 
	BankLog bankLog;
	CustomerAccount account;
	int accountNo;
	String password;

LogInAccount(int accountNo, String password){
	this.accountNo = accountNo;
	this.password = password;
	bankLog = new BankLog();
}
/**
 * call: is invoked and ran in a thread
 * Function: call first creates a customer account from the users entered account number and password
 * 			 The purpose of this is to compare the users entered data to the stored customer accounts
 * 			 The call method validates that the users ented account number meets the minimum requirments
 * 			 The account then invokes the bankLog login method to search through the accounts list which contains customer account objects
 * 			 If no exceptions are throughn the account has been successfully accessed and will invoke the Accounts Table in the bank database to access account information
 * 	@return: The users requested bank account
 * 
 * @exception: InvalidAccountException is thrown if a exception is thrown when validating the customers account or when logging int the customers account
 * @exception: InvlaidPasswordException is through if a exception occurs with the banklog login method
 */
@Override
public CustomerAccount call() throws InvalidAccountException, InvalidPasswordException {
	
	try {
		account = new CustomerAccount(accountNo, password);
	} catch (InvalidPasswordException e) {
		e.printStackTrace();
	}
	try {
		if(bankLog.validAccountNumber(accountNo)) {
			account = bankLog.dbLogin(account);
		}
		account = AccountTable.getAccount(account, account.getAccountNo());
		return account;
	} 
	catch(InvalidAccountException ex) {
		throw new InvalidAccountException("Unable to login into account", ex.getCause());
	} 
	catch (InvalidPasswordException ex) {
		throw new InvalidPasswordException("Unable to login into account", ex.getCause());
	}
  }

}
